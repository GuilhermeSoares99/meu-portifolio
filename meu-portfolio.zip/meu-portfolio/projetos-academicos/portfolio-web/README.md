# Projeto: Página Web Básica

Este projeto foi desenvolvido como parte do Bootcamp I para demonstrar conhecimentos básicos em HTML e CSS.

## Funcionalidades
- Exibição de mensagem de boas-vindas
- Estilização básica com CSS

## Como visualizar
Você pode abrir o arquivo `index.html` diretamente no navegador.

## Tecnologias usadas
- HTML5
- CSS3
