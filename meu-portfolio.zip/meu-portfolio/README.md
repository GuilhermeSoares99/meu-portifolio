# Meu Portfólio

Repositório criado para armazenar projetos acadêmicos e pessoais como parte do Bootcamp I - 2025.

## Estrutura

- **projetos-academicos/**: projetos feitos para atividades da faculdade/bootcamp
- **projetos-pessoais/** (em breve)

## Objetivo

Aplicar boas práticas de versionamento com Git, colaboração com pull requests, e integração com o LinkedIn.
